import open3d as o3d
import numpy as np

# Edge = o3d.io.read_point_cloud("plz.ply")
# Surface = o3d.io.read_point_cloud("surface_2.ply")


def normal_maker(Edge, Surface):
    # 1. 포인트 클라우드 읽기
    # pcd_Edge = o3d.io.read_point_cloud("/Users/leejongwon/Desktop/UNIST/COOP/han-mech/DTS/Workspace/DTS/DTS/FINAL_PJT/plz.ply")
    # pcd_Surface = o3d.io.read_point_cloud("/Users/leejongwon/Desktop/UNIST/COOP/han-mech/DTS/Workspace/DTS/DTS/FINAL_PJT/surface_2.ply")

    pcd_Edge = Edge
    pcd_Surface = Surface

    points_Edge = np.asarray(pcd_Edge.points)
    points_Surface = np.asarray(pcd_Surface.points)
    normals_Surface = np.asarray(pcd_Surface.normals)

    # 2. 중심 맞추기 (원점 이동)
    # KDTree로 B의 각 점에 대해 A에서 가장 가까운 점 찾기
    pcd_Edge_tree = o3d.geometry.KDTreeFlann(pcd_Edge)

    translations = []
    for p in points_Surface:
        [_, idx, _] = pcd_Edge_tree.search_knn_vector_3d(p, 1)  # 가장 가까운 A의 점
        nearest_Edge = points_Edge[idx[0]]
        translations.append(nearest_Edge - p)

    # 평균 translation
    avg_translation = np.mean(translations, axis=0)

    # B를 평균 translation만큼 이동
    pcd_Surface.translate(avg_translation)

    pcd_Edge.points = o3d.utility.Vector3dVector(points_Edge)
    pcd_Surface.points = o3d.utility.Vector3dVector(points_Surface)

    # 3. 좌표 → 법선 매핑 dict
    normal_dict = {tuple(p): n for p, n in zip(points_Surface, normals_Surface)}

    # KDTree (빠른 최근접 검색용)
    pcd_Surface_tree = o3d.geometry.KDTreeFlann(pcd_Surface)

    # 4. A의 각 점에 대해 법선 가져오기 (예외 처리: kNN 평균)
    normals_Edge = []
    k = 5  # 근처 이웃 개수

    for p in points_Edge:
        key = tuple(p)
        if key in normal_dict:
            normals_Edge.append(normal_dict[key])
        else:
            # 가까운 B의 점 k개 검색
            [_, idx, _] = pcd_Surface_tree.search_knn_vector_3d(p, k)
            neighbor_normals = normals_Surface[idx]
            avg_normal = np.mean(neighbor_normals, axis=0)
            avg_normal /= np.linalg.norm(avg_normal)  # 정규화
            normals_Edge.append(avg_normal)

    normals_Edge = np.array(normals_Edge)

    # 5. A에 법선 저장
    pcd_Edge.normals = o3d.utility.Vector3dVector(normals_Edge)

    # data = np.hstack((pcd_Edge.points, pcd_Edge.normals))
    # Edge_with_normal = data.tolist()  # numpy → 파이썬 리스트 변환
    points_arr  = np.asarray(pcd_Edge.points)
    normals_arr = np.asarray(pcd_Edge.normals)

    data = np.hstack((points_arr, normals_arr))  # (1841,6)
    print(data.shape)
    print(points_arr.shape)
    print(normals_arr.shape)
    # Edge_with_normal = data.tolist()             # list of [x,y,z,nx,ny,nz]

    # # 6. 결과 저장
    # o3d.io.write_point_cloud("Edge_with_normal.ply", pcd_Edge)
    # print("'Edge_with_normal.ply' 저장됨")

    return data

def scaling(Original):
    # Point cloud 읽기
    # pcd = o3d.io.read_point_cloud(Original)
    pcd = Original

    # ===== 1. 비율 축소 (0.9배) =====
    scale = 0.99
    points = np.asarray(pcd.points)
    scaled_points = points * scale

    pcd_scaled = o3d.geometry.PointCloud()
    pcd_scaled.points = o3d.utility.Vector3dVector(scaled_points)

    # ===== 2. 중심점 계산 =====
    centroid_A = np.mean(points, axis=0)
    centroid_B = np.mean(scaled_points, axis=0)

    # ===== 3. 원점으로 이동 =====
    # pcd.translate(-centroid_A)
    translation = centroid_A - centroid_B
    pcd_scaled.translate(translation)


    # ===== 4. 색상 지정 =====
    # pcd.paint_uniform_color([0.7, 0.7, 0.7])   # 원본 (회색)
    # pcd_scaled.paint_uniform_color([1, 0, 0]) # 축소본 (빨강)

    # ===== 5. 시각화 =====
    # o3d.visualization.draw_geometries([pcd, pcd_scaled])
    return pcd_scaled

def make_B_perp_to_A(A, B):
    A = np.array(A, dtype=float)
    B = np.array(B, dtype=float)
    n = np.cross(A, B)
    if np.linalg.norm(n) < 1e-8:
        return np.zeros(3)
    B_perp = np.cross(n, A)
    if np.linalg.norm(B_perp) > 1e-8:
        B_perp /= np.linalg.norm(B_perp)
    return B_perp

def rotation_matrix_to_quaternion(R):
    # """3x3 회전행렬 -> 쿼터니언 [x,y,z,w]"""
    m00, m01, m02 = R[0,0], R[0,1], R[0,2]
    m10, m11, m12 = R[1,0], R[1,1], R[1,2]
    m20, m21, m22 = R[2,0], R[2,1], R[2,2]
    tr = m00 + m11 + m22

    if tr > 0:
        S = np.sqrt(tr+1.0) * 2
        qw = 0.25 * S
        qx = (m21 - m12) / S
        qy = (m02 - m20) / S
        qz = (m10 - m01) / S
    elif (m00 > m11) and (m00 > m22):
        S = np.sqrt(1.0 + m00 - m11 - m22) * 2
        qw = (m21 - m12) / S
        qx = 0.25 * S
        qy = (m01 + m10) / S
        qz = (m02 + m20) / S
    elif m11 > m22:
        S = np.sqrt(1.0 + m11 - m00 - m22) * 2
        qw = (m02 - m20) / S
        qx = (m01 + m10) / S
        qy = 0.25 * S
        qz = (m12 + m21) / S
    else:
        S = np.sqrt(1.0 + m22 - m00 - m11) * 2
        qw = (m10 - m01) / S
        qx = (m02 + m20) / S
        qy = (m12 + m21) / S
        qz = 0.25 * S
    return np.array([qx, qy, qz, qw])

def orientation(Edge_with_normal):
    Oriented_Pose_List = []
    points = []
    normals = []
    for i in range(len(Edge_with_normal)):
        # points  = [row[:3] for row in Edge_with_normal]  # xyz
        # normals = [row[3:] for row in Edge_with_normal]  # normal
        points.append(Edge_with_normal[i][:3])
        normals.append(Edge_with_normal[i][3:])

    pcd = o3d.geometry.PointCloud()
    pcd.points  = o3d.utility.Vector3dVector(points)
    pcd.normals = o3d.utility.Vector3dVector(normals)

    # 포인트 클라우드 읽기
    # pcd = o3d.io.read_point_cloud(Edge_with_normal)
    # pcd = Ordering.order_boundary_points_3d(pcd)
    points = np.asarray(pcd.points)
    normals = np.asarray(pcd.normals)
    scaled = scaling(pcd)
    # scaled = Ordering.order_boundary_points_3d(scaled)

    # (예시) scaled는 그냥 같은 걸 쓰지만, 실제로는 따로 불러야 함
    scaled_points = np.asarray(scaled.points)

    # 벡터 차이
    vectors = [points[i] - scaled_points[i] for i in range(len(points))]

    # 각 점마다 pose 생성
    for i in range(len(points)):
        z = normals[i] / np.linalg.norm(normals[i])  # z축
        x = make_B_perp_to_A(z, vectors[i])          # x축
        if np.linalg.norm(x) < 1e-8:
            continue
        y = np.cross(z, x)
        y /= np.linalg.norm(y)

        # 회전행렬 -> 쿼터니언
        R = np.column_stack((x, y, z))
        q = rotation_matrix_to_quaternion(R)

        pose = [*points[i], *q]   # [x,y,z,qx,qy,qz,qw]
        Oriented_Pose_List.append(pose)

    return Oriented_Pose_List



def final(Edge, Surface):

    # Edge = "plz.ply"
    # Surface = "surface_2.ply"

    # New_edge = mapping.normal_maker(Edge, Surface)
    New_edge = normal_maker(Edge, Surface)

    final = orientation(New_edge)

    # print(final)
    # np.savetxt("final.txt", final, fmt="%.6f")
    return final