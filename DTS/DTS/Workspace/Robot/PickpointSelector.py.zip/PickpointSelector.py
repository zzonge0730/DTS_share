def PickpointSelector(unit, poselist):
    return poselist[::unit]
